﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;


namespace TARge20.Core.Domain
{
    public class Horse
    {
        [Key]
        public Guid Id { get; set; }
        public string HorseName { get; set; }
        public int Age { get; set; }
        public IEnumerable<Box> Boxes { get; set; } = new List<Box>();
        public IEnumerable<HorseOwner> HorseOwners { get; set; } = new List<HorseOwner>();
        public IEnumerable<HorseTrainer> HorseTrainers { get; set; } = new List<HorseTrainer>();
        public IEnumerable<PreviousOwners> PreviousOwners { get; set; } = new List<PreviousOwners>();
        public IEnumerable<PreviousTrainers> PreviousTrainers { get; set; } = new List<PreviousTrainers>();

    }
}
