﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TARge20.Core.Domain;

namespace TARge20.Data
{
    public class TARge20DbContext : DbContext
    {

        public TARge20DbContext(DbContextOptions<TARge20DbContext> options)
            : base(options) { }

        // näide, kuidas teha, kui lisate domaini alla ühe objekti
        // migratsioonid peavad tulema siia libary-sse e TARge20.Data alla.

        /*
        public DbSet<Employee> Employee { get; set; }
        public DbSet<AdministrationAccess> AdministrationAccesses { get; set; }
        public DbSet<Area> Area { get; set; }
        public DbSet<Branch> Branches { get; set; }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<EmployeeArea> EmployeeAreas { get; set; }
        public DbSet<EmployeeKids> EmployeeKids { get; set; }
        public DbSet<EmployeeOccupation> EmployeeOccupations { get; set; }
        public DbSet<EmployeeAccess> EmployeeAccesses { get; set; }
        public DbSet<Firm> Firm { get; set; }
        public DbSet<HealthCheck> HealthChecks { get; set; }
        public DbSet<Hints> Hints { get; set; }
        public DbSet<IllnesSheet> IllnesSheets { get; set; }
        public DbSet<LoanFromFirm> LoanFromFirms { get; set; }
        public DbSet<Requests> Requests { get; set; }
        public DbSet<Vacations> Vacations { get; set; }
        public DbSet<VacationStatus> VacationStatuses { get; set; }
        */

    }
}