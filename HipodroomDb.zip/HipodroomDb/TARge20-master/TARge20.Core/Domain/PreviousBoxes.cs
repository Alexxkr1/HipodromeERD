﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;


namespace TARge20.Core.Domain
{
    public class PreviousBoxes
    {
        [Key]
        public Guid Id { get; set; }
    }
}
