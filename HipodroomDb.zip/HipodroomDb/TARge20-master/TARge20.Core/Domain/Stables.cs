﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;


namespace TARge20.Core.Domain
{
    public class Stables
    {
        [Key]
        public Guid Id { get; set; }
    }

    public IEnumerable<Box> Box { get; set; } = new List<Box>();
}
