﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;


namespace TARge20.Core.Domain
{
    public class PreviousOwners
    {
        [Key]
        public Guid Id { get; set; }
        public string Name { get; set; }
        public bool Empty { get; set; }
    }
}
