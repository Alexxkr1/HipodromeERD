﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;


namespace TARge20.Core.Domain
{
    public class Competitions
    {
        [Key]
        public Guid Id { get; set; }

        public IEnumerable<CompetitionResults> CompetitionResults { get; set; } = new List<CompetitionResults>();
        public IEnumerable<CompetitionSignUp> CompetitionSignUp { get; set; } = new List<CompetitionSignUp>();
    }
}
